PROJET : TP JavaScript - TP2 et 4 exercices

Dossiers :
- TP2 : questions 1 à 15 du document TP2 JavaScript.
- Exercices : QCM, validation email, tri d'un tableau, somme de trois temps.

Chaque fichier HTML contient son HTML, son CSS et son JavaScript afin de pouvoir être testé directement dans un navigateur.

Pour GitHub :
1. Télécharge et décompresse ce dossier sur ton ordinateur.
2. Ouvre ton repository GitHub.
3. Clique sur Add file > Upload files.
4. Dépose le contenu des dossiers TP2 et Exercices ainsi que README.txt.
5. Clique sur Commit changes.

Vérifie avec les consignes exactes de ton professeur avant de rendre le travail.
